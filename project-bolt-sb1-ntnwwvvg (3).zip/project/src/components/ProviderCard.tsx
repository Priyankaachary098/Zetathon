import React from 'react';
import { Star } from 'lucide-react';
import { Provider } from '../types';

interface ProviderCardProps {
  provider: Provider;
}

export default function ProviderCard({ provider }: ProviderCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
      <img
        src={provider.image}
        alt={provider.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">{provider.name}</h3>
        <div className="flex items-center mb-2">
          <Star className="h-5 w-5 text-yellow-400 fill-current" />
          <span className="ml-1 text-sm font-medium">{provider.rating}</span>
          <span className="ml-1 text-sm text-gray-500">
            ({provider.reviews} reviews)
          </span>
        </div>
        <button className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors">
          Book Now
        </button>
      </div>
    </div>
  );
}