import React from 'react';
import { Bot, MessageSquare, Lightbulb, HelpCircle } from 'lucide-react';

export default function AIAssistant() {
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="bg-white rounded-lg shadow-lg p-4 w-80">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Bot className="h-6 w-6 text-indigo-600 mr-2" />
            <h3 className="font-semibold">ZETA Assistant</h3>
          </div>
          <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Online</span>
        </div>
        
        <div className="space-y-2">
          <button className="w-full flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
            <MessageSquare className="h-5 w-5 text-indigo-600 mr-2" />
            <span>Chat with Support</span>
          </button>
          <button className="w-full flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
            <Lightbulb className="h-5 w-5 text-indigo-600 mr-2" />
            <span>Service Recommendations</span>
          </button>
          <button className="w-full flex items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
            <HelpCircle className="h-5 w-5 text-indigo-600 mr-2" />
            <span>Quick Help</span>
          </button>
        </div>
      </div>
    </div>
  );
}